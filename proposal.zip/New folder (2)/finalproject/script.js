//Event listeners
document.querySelector(".calculate").addEventListener("click",
BMI)

document.querySelector(".clear").addEventListener("click", Clear)



//claculate function
function BMI() {
  const height = document.getElementById('height').value;
  const weight = document.getElementById('weight').value;

//BMI formula
let index = (weight / (((height / 100) * height) / 100)).toFixed(0);

//condition to check if height and weight are not equal to Zero
 if (height && weight !=0) {
   const output = document.getElementById("output");
   const state = document.getElementById("state");
   output.innerHTML = "Your BMI is " + index;
   if(index < 15 ){
     state.innerHTML = "Very severly Underweight!"
   }


  } else {
    alert('Error!')
 }

}


//Clear function
function Clear() {
    document.getElementById('height').value = "";
    document.getElementById('weight').value = "";
    document.getElementById('output').value = "";
    document.getElementById('state').value = "";
}